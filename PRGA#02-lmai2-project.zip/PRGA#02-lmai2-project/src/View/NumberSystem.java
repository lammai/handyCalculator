package View;

/**
 * The number systems that can be used.
 */
public enum NumberSystem {
    Binary,
    Hex
}