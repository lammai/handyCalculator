# Handy Calculator for CS students

## Introduction

> This program contains three different types of calculator. It supports calculations/conversions for Binary, Hexadecimal, and Bandwidth. 

## Installation
Download and extract PRGA#03-mai_lam-project.zip
> You should be able to import the project into your favorite IDE, below is instruction for IntelliJ IDEA.

To import the project into IntelliJ IDEA:  
- In IntelliJ IDEA -> Open or Import -> PRGA#03-mai_lam-project
- From there you should be able to run CalculatorGUI.java on IntelliJ as well as the Test classes included.   